export interface IUser{
    UserId:number,
    fullName :string,
    email:string,
    password:string
    
}