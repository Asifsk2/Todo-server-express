export default interface Todo{
    title:string,
    description:string,
    userId: String
}